package lab1;

public class Greeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello, Steve");
	}

}
